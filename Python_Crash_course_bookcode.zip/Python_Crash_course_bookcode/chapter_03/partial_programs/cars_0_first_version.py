cars = ['bmw', 'audi', 'toyota', 'subaru']
cars.sort()
print(cars)