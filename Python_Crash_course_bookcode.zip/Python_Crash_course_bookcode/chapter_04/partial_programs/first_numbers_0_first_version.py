for value in range(1, 5):
    print(value)