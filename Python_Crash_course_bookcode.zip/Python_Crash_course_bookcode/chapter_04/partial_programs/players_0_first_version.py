players = ['charles', 'martina', 'michael', 'florence', 'eli']
print(players[0:3])