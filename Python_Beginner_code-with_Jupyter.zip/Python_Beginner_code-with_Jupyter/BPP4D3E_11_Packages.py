#!/usr/bin/env python
# coding: utf-8

# # Creating Code Groupings

# ## Creating your first package

# In[1]:


def SayHello(Name):
   print("Hello ", Name)
   return
def SayGoodbye(Name):
   print("Goodbye ", Name)
   return


# In[ ]:




