alien_color = 'green'

if alien_color == 'green':
    print("You just earned 5 points!")
