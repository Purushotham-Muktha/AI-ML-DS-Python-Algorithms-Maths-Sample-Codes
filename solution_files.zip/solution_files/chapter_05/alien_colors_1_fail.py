alien_color = 'red'

if alien_color == 'green':
    print("You just earned 5 points!")
