animals = ["spider monkey", "lemur", "giraffe"]

# Print each animal.
for animal in animals:
    print(animal)

print("\n")

# Print a statement about each animal.
for animal in animals:
    print(f"A {animal} has a long tail.")

print("\nAll of these animals have long tails.")
