odd_numbers = list(range(1, 20, 2))

for number in odd_numbers:
    print(number)
