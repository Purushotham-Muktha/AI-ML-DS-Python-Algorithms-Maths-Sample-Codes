threes = list(range(3, 31, 3))

for number in threes:
    print(number)
