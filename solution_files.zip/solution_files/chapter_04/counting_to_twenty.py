numbers = list(range(1, 21))

for number in numbers:
    print(number)
