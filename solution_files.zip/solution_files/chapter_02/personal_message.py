name = "eric"
msg = f"Hello {name.title()}, would you like to learn some Python today?"

print(msg)