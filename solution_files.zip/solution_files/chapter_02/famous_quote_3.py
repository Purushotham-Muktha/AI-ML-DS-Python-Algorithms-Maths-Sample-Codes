famous_person = "Albert Einstein"

message = f'{famous_person} once said, "A person who never made a mistake'
message += ' never tried anything new."'

print(message)