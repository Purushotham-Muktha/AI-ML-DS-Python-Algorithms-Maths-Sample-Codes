filename = 'python_notes.txt'
simple_filename = filename.removesuffix('.txt')

print(simple_filename)