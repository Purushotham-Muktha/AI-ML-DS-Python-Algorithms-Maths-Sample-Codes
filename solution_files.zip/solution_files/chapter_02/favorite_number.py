fav_num = 42
msg = f"My favorite number is {fav_num}."

print(msg)