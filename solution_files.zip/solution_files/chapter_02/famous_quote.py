print('Albert Einstein once said, "A person who never made a mistake')
print('never tried anything new."')