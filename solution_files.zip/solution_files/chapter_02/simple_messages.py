msg = "I love learning to use Python."
print(msg)

msg = "It's really satisfying!"
print(msg)
