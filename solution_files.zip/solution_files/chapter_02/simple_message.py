msg = "I love learning to use Python."
print(msg)
